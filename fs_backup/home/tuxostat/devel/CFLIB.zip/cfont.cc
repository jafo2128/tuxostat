/*
CFONT - Crystalfontz CFA-635/CFA-631 Control Program
Version 2.0 (2007)
Programmed & Modified by Keven Tipping, Psuedo-Copyright 2007.
Portions of this code from the Crystalfontz Forum.
*/

/*************************************************************************/
/**  INCLUDES                                                           **/
/*************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <termios.h>
#include <unistd.h>
#include <fcntl.h>
#include <ctype.h>
#include <sys/time.h>
#include <sys/types.h>
#include <string.h>
#include "cflib.h"

/*************************************************************************/
/**  TYPEDEFS                                                           **/
/*************************************************************************/

typedef struct cmd {		// Struct for the commands parsed from the CLI
	char	*type;			// Type of command (ie, led, dev, print, etc)
	char	*opt[32];		// Options fo the command (ie, x&y coords, etc)
	int		optc;			// Option array size (this is set when opt is populated)
	cmd() {
		optc=0;				//Set optc to zero at initialization
	}
} command;

/*************************************************************************/
/**  COMMON FUNCTIONS                                                   **/
/*************************************************************************/

static bool silent;

static uint8 data[24];
static uint8 type;

void data_handler (LCD_PACKET_DATA *p, void *info) {
	type = p->type;
	for (int i=0; i<p->length; i++) {
		data[i] = p->info[i];
	}
}

void clear_data () {
	type = 0;
	for (int i=0; i<24; i++) {
		data[i] = 0;
	}
}

// Important Note: wait_for_data expects a event ID...
// This is basically a hex code as defined by CrystalFontz
// that determines what sort of type return code any command
// should return. Wait_for_data uses this to determine if the
// expected packet was returned, or if something else was returned
// instead (like a keypress or DOW event).

// These event reply codes are documented in cflib.h.

int wait_for_data (int event, int timeout) {
	int time=0;
	timeout = timeout*1000;
	while( type != event && time < timeout ) {
		// Check type for errant data. Clear it if it's present and NOT
		// the type code we are actually waiting for.
		if ( type != 0 && type != event ) clear_data();
		usleep(100);
		time++;
	}
	if ( time >= timeout ) {
		return 1;
	} else {
		return 0;
	}
}

int check_bounds(int x, int y) {
	int max_x = 19;
	int max_y = 3;
	if ( x < 0 || x > max_x || y < 0 || y > max_y ) {
		return 1;
	}
	return 0;
}

/*************************************************************************/
/**  USAGE                                                              **/
/*************************************************************************/

void usage()
{
	printf("\n");
	printf("CFONT - Crystalfontz CLI Utility");
	printf("CFONT - Release version 2.0\n");
	printf("\n");
	printf("See included readme for details on available commands.\n");
	printf("Available commands are:\n");
	printf("--dev $device, --ping, --version, --readflash\n");
	printf("--writeflash $string, --get $line, --storeboot, --reboot\n");
	printf("--clear, --cursor $x $y, --cstyle $style, --contrast $value\n");
	printf("--backlight $value, --led $led $green $red OR --led $green $red\n");
	printf("--print $x $y $string, --printc $x $y $char, --getkey $timeout\n");
	printf("--silent (suppress all messages)\n");
	printf("Multiple (chained) commands are executed left to right.\n");
	printf("\n");
	printf("For command help, execute a blank command (ie, -menu).\n");
	printf("\n");
}

/*************************************************************************/
/**  WRAPPER FUNCTIONS                                                  **/
/*************************************************************************/

int ping(command cmd) {
	if (cmd.optc > 0) {
		if (!silent) printf("CFONT: In function 'ping': Ping requires no options\n");
		return 1;
	} else {
		cfont_ping(42); // Because the meaning of life is to program CFA display
		if (wait_for_data(CFONT635_EVENT_PING, 5) == 0) {
			printf("alive\n");
		} else {
			printf("timeout\n");
		}
		clear_data();
		return 0;
	}
}

int version(command cmd) {
	if (cmd.optc > 0) {
		if (!silent) printf("CFONT: In function 'version': Version requires no options\n");
		return 1;
	} else {
		cfont_get_version();
		if (wait_for_data(CFONT635_EVENT_VERSION, 5) == 0) {
			printf("%s\n", data);
		} else {
			printf("timeout\n");
		}
		return 0;
	}
}

int readflash(command cmd) {
	if (cmd.optc > 0) {
		if (!silent) printf("CFONT: In function 'readflash': Readflash requires no options\n");
		return 1;
	} else {
		cfont_get_flash();
		if (wait_for_data(CFONT635_EVENT_READFLASH, 5) == 0) {
			printf("%s\n", data);
		} else {
			printf("timeout\n");
		}
		return 0;
	}
}

int writeflash(command cmd) {
	if (cmd.optc != 1) {
		if (!silent) printf("CFONT: In function 'writeflash': Writeflash requires a <=16 Byte String\n");
		return 1;
	} else {
		char string[16];
		if ( strlen(cmd.opt[0]) > 16 ) {
			strncpy(string, cmd.opt[0], 16); // String is > 16 characters, chop it to 16
		} else {
			sprintf(string, "%-*s", 16, cmd.opt[0]); // String is < 16 characters, pad it to 16
		}
		cfont_set_flash(string);
		return 0;
	}
}

int storeboot(command cmd) {
	if (cmd.optc > 0) {
		if (!silent) printf("CFONT: In function 'storeboot': Storeboot requires no options\n");
		return 1;
	} else {
		cfont_store_boot_state();
		return 0;
	}
}

int reboot(command cmd) {
	if (cmd.optc > 0) {
		if (!silent) printf("CFONT: In function 'reboot': Reboot requires no options\n");
		return 1;
	} else {
		cfont_reboot();
		return 0;
	}
}

int clear(command cmd) {
	if (cmd.optc > 0) {
		if (!silent) printf("CFONT: In function 'clear': Clear requires no options\n");
		return 1;
	} else {
		cfont_clear();
		return 0;
	}
}

int cursor(command cmd) {
	if (cmd.optc != 2) {
		if (!silent) printf("CFONT: In function 'cursor': Cursor requires X and Y coords\n");
		return 1;
	} else {
		int x = atoi(cmd.opt[0]);
		int y = atoi(cmd.opt[1]);
		if (check_bounds(x, y) == 0) {
			cfont_set_cursor_position(x, y);
		} else {
			if (!silent) printf("CFONT: In function 'cursor': X(%d) or Y(%d) out of range\n", x, y);
			return 1;
		}
		return 0;
	}
}

int cstyle(command cmd) {
	if (cmd.optc != 1) {
		if (!silent) printf("CFONT: In function 'cstyle': Cstyle requires a style integer\n");
		return 1;
	} else {
		int style = atoi(cmd.opt[0]);
		if (style > 4 || style < 0) {
			if (!silent) printf("CFONT: In function 'cstyle': Cursor style (%d) out of range\n", style);
			return 1;
		} else {
			cfont_set_cursor_style(style);
		}
		return 0;
	}
}

int contrast(command cmd) {
	if (cmd.optc != 1) {
		if (!silent) printf("CFONT: In function 'contrast': Contrast requires a value (0-99)\n");
		return 1;
	} else {
		int contrast = atoi(cmd.opt[0]);
		if (contrast > 99 || contrast < 0) {
			if (!silent) printf("CFONT: In function 'contrast': Contrast (%d) out of range\n", contrast);
			return 1;
		} else {
			cfont_set_contrast(contrast);
		}
		return 0;
	}
}

int backlight(command cmd) {
	if (cmd.optc != 1) {
		if (!silent) printf("CFONT: In function 'backlight': Backlight requires a value (0-100)\n");
		return 1;
	} else {
		int backlight = atoi(cmd.opt[0]);
		if (backlight > 100 || backlight < 0) {
			if (!silent) printf("CFONT: In function 'backlight': Backlight (%d) out of range\n", backlight);
			return 1;
		} else {
			cfont_set_backlight(backlight);
		}
		return 0;
	}
}

int led(command cmd) {
	if (cmd.optc > 3 || cmd.optc < 2) {
		if (!silent) printf("CFONT: In function 'led': Led requires a LED number, green and red values\n");
		if (!silent) printf("CFONT: In function 'led': or no LED number to apply to all 4 LED's\n");
		return 1;
	} else {
		if (cmd.optc == 2) {
			int led_g = atoi(cmd.opt[0]);
			int led_r = atoi(cmd.opt[1]);
			if ( led_g < 0 || led_g > 100 || led_r < 0 || led_r > 100 ) {
				if (!silent) printf("CFONT: In function 'led': Led Green (%d) or Red (%d) out of range\n", led_g, led_r);
				return 1;
			} else {
				for (int i=1; i<=4; i++) {
					cfont_set_led(i, led_g, led_r);
				}
			}
		} else {
			int led = atoi(cmd.opt[0]);
			int led_g = atoi(cmd.opt[1]);
			int led_r = atoi(cmd.opt[2]);
			if ( led < 1 || led > 4 || led_g < 0 || led_g > 100 || led_r < 0 || led_r > 100 ) {
				if (!silent) printf("CFONT: In function 'led': Led (%d) Green (%d) or Red (%d) out of range\n", led, led_g, led_r);
				return 1;
			} else {
				cfont_set_led(led, led_g, led_r);
			}
		}
		return 0;
	}
}

int print(command cmd) {
	if (cmd.optc != 3) {
		if (!silent) printf("CFONT: In function 'print': Print requires an x and y coord and a string\n");
		return 1;
	} else if (strlen(cmd.opt[2]) == 0) {
		if (!silent) printf("CFONT: In function 'print': Print requires a non-null string\n");
		return 1;
	} else {
		int x = atoi(cmd.opt[0]);
		int y = atoi(cmd.opt[1]);
		char string[20];
		if (strlen(cmd.opt[2]) > 20) {
			strncpy(string, cmd.opt[2], 20);
		} else {
			strcpy(string, cmd.opt[2]);
		}
		if (check_bounds(x, y) == 0) {
			cfont_write_xy(x, y, string, strlen(string));
		} else {
			if (!silent) printf("CFONT: In function 'print': X(%d) or Y(%d) out of range\n", x, y);
			return 1;
		}
		return 0;
	}
}

int printc(command cmd) {
	if (cmd.optc != 3) {
		if (!silent) printf("CFONT: In function 'printc': Printc requires an x and y coord and a char integer\n");
		return 1;
	} else {
		int x = atoi(cmd.opt[0]);
		int y = atoi(cmd.opt[1]);
		int c = atoi(cmd.opt[2]);
		if (check_bounds(x, y) == 0) {
			cfont_write_char_xy(x, y, c);
		} else {
			if (!silent) printf("CFONT: In function 'printc': X(%d) or Y(%d) out of range\n", x, y);
			return 1;
		}
		return 0;
	}
}

int get(command cmd) {
	if (cmd.optc != 1) {
		if (!silent) printf("CFONT: In function 'get': Get requires a line number\n");
		return 1;
	} else {
		int addr=(128+(atoi(cmd.opt[0])-1)*32);
		int c=0;
		char buf[20];
		for(int i=0; i<3; i++) {
			clear_data();
			cfont_get_ddcgram(addr+(i*8));
			if (wait_for_data(CFONT635_EVENT_DDRAM, 5) == 0) {
				for (int b=1; b<9; b++) {
					if(c+1>20) {
						break;
					} else {
						sprintf(&buf[c], "%c", data[b]);
						c++;
					}
				}
			} else {
				printf("timeout\n");
				return 1;
			}
		}
		printf("%s\n", buf);
		return 0;
	}
}

int getkey(command cmd) {
	if (cmd.optc != 1) {
		if (!silent) printf("CFONT: In function 'getkey': Getkey a timeout value\n");
		return 1;
	} else {
		if (wait_for_data(CFONT635_EVENT_KEY, atoi(cmd.opt[0])) == 0) {
			printf("%d\n", data[0]);
		} else {
			printf("timeout\n");
		}
		return 0;
	}
}

/*************************************************************************/
/**  EXEC ENGINE                                                        **/
/*************************************************************************/

int exec(int c, command cmds[]) {
	cfont_register_event_handler(data_handler, NULL); // Launch the event handler
	for (int i=0; i<c; i++) {
		clear_data(); // Clear the data[] and type variables automatically
		if ( strcmp(cmds[i].type, "--dev") == 0 ) {
			// Do nothing, --dev is parsed before exec() is called
		} else if ( strcmp(cmds[i].type, "--silent") == 0 ){
			// Do nothing, --silent is parsed before exec() is called
		} else if ( strcmp(cmds[i].type, "--ping") == 0 ){
			ping(cmds[i]);
		} else if ( strcmp(cmds[i].type, "--version") == 0 ){
			version(cmds[i]);
		} else if ( strcmp(cmds[i].type, "--readflash") == 0 ){
			readflash(cmds[i]);
		} else if ( strcmp(cmds[i].type, "--writeflash") == 0 ){
			writeflash(cmds[i]);
		} else if ( strcmp(cmds[i].type, "--storeboot") == 0 ){
			storeboot(cmds[i]);
		} else if ( strcmp(cmds[i].type, "--reboot") == 0 ){
			reboot(cmds[i]);
		} else if ( strcmp(cmds[i].type, "--clear") == 0 ){
			clear(cmds[i]);
		} else if ( strcmp(cmds[i].type, "--cursor") == 0 ){
			cursor(cmds[i]);
		} else if ( strcmp(cmds[i].type, "--cstyle") == 0 ){
			cstyle(cmds[i]);
		} else if ( strcmp(cmds[i].type, "--contrast") == 0 ){
			contrast(cmds[i]);
		} else if ( strcmp(cmds[i].type, "--backlight") == 0 ){
			backlight(cmds[i]);
		} else if ( strcmp(cmds[i].type, "--led") == 0 ){
			led(cmds[i]);
		} else if ( strcmp(cmds[i].type, "--print") == 0 ){
			print(cmds[i]);
		} else if ( strcmp(cmds[i].type, "--printc") == 0 ){
			printc(cmds[i]);
		} else if ( strcmp(cmds[i].type, "--getkey") == 0 ){
			getkey(cmds[i]);
		} else if ( strcmp(cmds[i].type, "--get") == 0 ){
			get(cmds[i]);
		} else {
			printf("CFONT: Command %s is unknown, ignoring...\n", cmds[i].type);
		}
	}
}

/*************************************************************************/
/**  MAIN AND PARSER                                                    **/
/*************************************************************************/

int main( int argc, char *argv[] )
{
	if ( argc <= 1 ) {
		usage(); // Print the usage screen if no CLI arguments
	} else {
		// First, check how many commands (not options) we have
		int c = 0;
		for (int i=1; i<argc; i++) {
			if (strstr(argv[i], "--") != NULL ) c++;
		}

		// Create the cmds struct array to hold the parsed CLI arguments
		// Note that this is dynamic depending on the number of commands
		// found by the previous FOR loop.
		//printf("DEBUG: CMD Count = %d\n", c);
		command *cmds;
		cmds = new cmd [ c ];

		// Now, we parse the entire argv (CLI arguments) array into the cmds struct array
		// You may have noticed that i=1, not i=0 in these for loops. That's because when
		// i=0, argv[i] effectly returns the program path. Figuring that we're only
		// interested in the program arguments, i=1 to skip the contents of argv[0].

		int cmdindex = -1;
		int optindex = 0;
		for (int i=1; i<argc; i++) {
			if ( strstr(argv[i], "--") != NULL ) {
				cmdindex ++;
				cmds[cmdindex].type = argv[i];
				optindex = 0;
				//printf("DEBUG: Command = %s, Index = %d\n", cmds[cmdindex].type, cmdindex);
			} else {
				if ( cmds[cmdindex].type != NULL && strlen(cmds[cmdindex].type) != 0 ) {
					cmds[cmdindex].opt[optindex] = argv[i];
					//printf("DEBUG: Option = %s, Index = %d\n", cmds[cmdindex].opt[optindex], optindex);
					cmds[cmdindex].optc ++;
					optindex ++;
				} else {
					printf("CFONT: '%s' is not a member of a function!\n", argv[i]);
				}
			}
		}

		// Now that parsing is complete and we have a populated cmds struct array
		// Sort through cmds[] to find a suitable --dev option to open the CFA display with.
		int fd = 0;
		silent = false;
		for (int i=0; i<c; i++) {
			if (strcmp(cmds[i].type, "--dev") == 0) {
				if (cmds[i].optc == 1) {
					fd = cfont_open(cmds[i].opt[0]);
				} else {
					printf("CFONT: In function 'dev': Dev requires a device path\n");
					fd = 1;
				}
			} else if (strcmp(cmds[i].type, "--silent") == 0) {
				silent = true;
			}
		}

		switch (fd) {
			case 0:
				printf("CFONT: Missing --dev option, nothing left to do\n");
				break;
			case -1:
				printf("error\n");
				break;
			case 1:
				break;
			default:
				exec(c, cmds);
				cfont_close();
				break;
		}

		// Program has finished
		delete [] cmds;				// Clean up the cmds struct array
		return 0;					// Goodbye blue sky.
	}
}
