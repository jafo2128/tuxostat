/*
CFLIB - Crystalfontz CFA-635/CFA-631 Control Library
Version 2.0 (2007)
Programmed & Modified by Keven Tipping, Psuedo-Copyright 2007.
Portions of this code from the Crystalfontz Forum.
*/

/*************************************************************************/
/**  INCLUDES                                                           **/
/*************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <termios.h>
#include <unistd.h>
#include <fcntl.h>
#include <ctype.h>
#include <sys/time.h>
#include <sys/types.h>
#include "cflib.h"

/*************************************************************************/
/**  TYPEDEFS                                                           **/
/*************************************************************************/

#if 0
typedef int                int32;
typedef unsigned short int uint16;
typedef unsigned char      uchar8;
typedef unsigned char      uint8;
typedef unsigned int       uint32;

typedef union {
        uint16  word;
        uint8 byte[2];
} WORD;

typedef struct {
        uint8 type;
        uint8 length;
        uint8 info[24];
} LCD_PACKET_DATA;

typedef union {
        LCD_PACKET_DATA packet;
        uint8 buffer[256];
} LCD_SEND_DATA;

typedef union {
        LCD_PACKET_DATA packet;
        uint8 buffer[256];
} LCD_RECEIVE_DATA;

#define BUFFER_MAX_SIZE 256

typedef struct {
        LCD_SEND_DATA *buffer[BUFFER_MAX_SIZE];
        int len;
        int tail;
        int head;
        void (*event_handler) (LCD_PACKET_DATA *p, void *info);
        void *info;
        int reset_after_end;
} LCD_SEND_BUFFER;
#endif

/*************************************************************************/
/**  STATIC DECLARATIONS                                                **/
/*************************************************************************/

static LCD_SEND_BUFFER __lcd_send_buffer;
static pthread_t __lcd_thread;
static pthread_mutex_t __send_buffer_mutex;
static int __thread_loop = 1;
static int __fd = 0;

static void send_data_with_crc (LCD_SEND_DATA *data);
static uint16 get_crc(const uint8 *bufptr, uint16 len, const uint16 seed);
static void *lcd_635_thread (void *thread_data);

static void dispatch_lcd_event (const LCD_PACKET_DATA *packet);

/*************************************************************************/
/**  CONSTANTS                                                          **/
/*************************************************************************/

#if 0

/* Report Codes */
#define CFONT635_EVENT_KEY		0x80

/* Keycodes */

#define CFONT635_KEYPAD_PRESS_UP		1
#define CFONT635_KEYPAD_PRESS_DOWN		2
#define CFONT635_KEYPAD_PRESS_LEFT		3
#define CFONT635_KEYPAD_PRESS_RIGHT		4
#define CFONT635_KEYPAD_PRESS_ENTER		5
#define	CFONT635_KEYPAD_PRESS_EXIT		6
#define CFONT635_KEYPAD_RELEASE_UP		7
#define CFONT635_KEYPAD_RELEASE_DOWN	8
#define CFONT635_KEYPAD_RELEASE_LEFT	9
#define CFONT635_KEYPAD_RELEASE_RIGHT	10
#define CFONT635_KEYPAD_RELEASE_ENTER	11
#define	CFONT635_KEYPAD_RELEASE_EXIT	12


/* Cursor Styles */

#define CFONT635_CURSOR_STYLE_NO_CURSOR         0
#define CFONT635_CURSOR_STYLE_BLINK             1
#define CFONT635_CURSOR_STYLE_UNDERSCORE        2
#define CFONT635_CURSOR_STYLE_BLINK_UNDER       3
#define CFONT635_CURSOR_STYLE_INVERTING_BLINK   4

#endif
 
/*************************************************************************/
/**  ASCII TRANSLATION (Not required in Firmware 2?)                    **/
/*************************************************************************/

/*
static uint8 cfont635_ascii_translation[256] = {
        {36, '$', 162},
        {64, '@', 160},
        {91, '[', 250},
        {92, '\', 251},
        {93, ']', 252},
        {94, '^',  29},
        {95, '_', 196},
        {96, '`', 000},
        {123, '{', 253},
        {124, '|', 254},
        {125, '}', 255},
        {126, '~', 206},
        {183, '·', 221},
        {209, 'Ñ',  93},
        {225, 'á', 231},
        {233, 'é', 165},
        {237, 'í', 232},
        {243, 'ó', 233},
        {241, 'ñ', 125},
        {250, 'ú', 234},

        {220, 'Ü',  94},
        {252, 'ü', 126},
        {191, '¿',  96},
        {161, '¡',  64},
        {186, 'º', 128},
        {231, 'ç', 200},
        {199, 'Ç', 169},
};
*/

static uint8 cfont_ascii_translation[256] = {
          0,   1,   2,   3,   4,   5,   6,   7,   8,   9,
         10,  11,  12,  13,  14,  15,  16,  17,  18,  19,
         20,  21,  22,  23,  24,  25,  26,  27,  28,  29,
         30,  31,  32,  33,  34,  35, 162,  37,  38,  39,
         40,  41,  42,  43,  44,  45,  46,  47,  48,  49,
         50,  51,  52,  53,  54,  55,  56,  57,  58,  59,
         60,  61,  62,  63, 160,  65,  66,  67,  68,  69,
         70,  71,  72,  73,  74,  75,  76,  77,  78,  79,
         80,  81,  82,  83,  84,  85,  86,  87,  88,  89,
         90, 250, 251, 252,  29, 196,  96,  97,  98,  99,
        100, 101, 102, 103, 104, 105, 106, 107, 108, 109,
        110, 111, 112, 113, 114, 115, 116, 117, 118, 119,
        120, 121, 122, 253, 254, 255, 206, 127, 128, 129,
        130, 131, 132, 133, 134, 135, 136, 137, 138, 139,
        140, 141, 142, 143, 144, 145, 146, 147, 148, 149,
        150, 151, 152, 153, 154, 155, 156, 157, 158, 159,
        160,  64, 162, 163, 164, 165, 166, 167, 168, 169,
        170, 171, 172, 173, 174, 175, 176, 177, 178, 179,
        180, 181, 182, 221, 184, 185, 128, 187, 188, 189,
        190,  96, 192, 193, 194, 195, 196, 197, 198, 169,
        200, 201, 202, 203, 204, 205, 206, 207, 208,  93,
        210, 211, 212, 213, 214, 215, 216, 217, 218, 219,
         94, 221, 222, 223, 224, 231, 226, 227, 228, 229,
        230, 200, 232, 165, 234, 235, 236, 232, 238, 239,
        240, 125, 242, 233, 244, 245, 246, 247, 248, 249,
        234, 251, 126, 253, 254, 255
};

/*************************************************************************/
/**  HIGH-LEVEL FUNCTIONS (Easy Wrappers?)                              **/
/*************************************************************************/

void cfont_ping(const int ping_data) {
	LCD_SEND_DATA data;
	data.packet.type = 0;
	data.packet.length = 1;
	data.packet.info[0] = (uint8) ping_data;
	send_data_with_crc (&data);
}

void cfont_get_version() {
	LCD_SEND_DATA data;
	data.packet.type = 1;
	data.packet.length = 0;
	send_data_with_crc (&data);
}

void cfont_set_flash(const char *string) {
	LCD_SEND_DATA data;
	data.packet.type = 2;
	data.packet.length = 16;
	for (int i=0; i < 16; i++) {
		data.packet.info[i] = (uint8) string[i];
	}
	send_data_with_crc (&data);
}

void cfont_get_flash() {
	LCD_SEND_DATA data;
	data.packet.type = 3;
	data.packet.length = 0;
	send_data_with_crc (&data);
}

void cfont_store_boot_state () {
	LCD_SEND_DATA data;
	data.packet.type = 4;
	data.packet.length = 0;
	send_data_with_crc (&data);
}

void cfont_reboot () {
	LCD_SEND_DATA data;
	data.packet.type = 5;
	data.packet.length = 3;
	data.packet.info[0] = 8;
	data.packet.info[1] = 18;
	data.packet.info[2] = 99;
	send_data_with_crc (&data);
}

void cfont_clear () {
	LCD_SEND_DATA data;
	data.packet.type = 6;
	data.packet.length = 0;
	send_data_with_crc (&data);
}

void cfont_set_cursor_position (const int x, const int y) {
	LCD_SEND_DATA data;
	data.packet.type = 11;
	data.packet.length = 2;
	data.packet.info[0] = (uint8) x;
	data.packet.info[1] = (uint8) y;
	send_data_with_crc (&data);
}

void cfont_set_cursor_style (const int style) {
	LCD_SEND_DATA data;
	data.packet.type = 12;
	data.packet.length = 1;
	data.packet.info[0] = (uint8) style;
	send_data_with_crc (&data);
}

void cfont_set_contrast (const int level_percent) {
	LCD_SEND_DATA data;
	int level;
	level = (level_percent * 255) / 100;
	data.packet.type = 13;
	data.packet.length = 1;
	data.packet.info[0] = (uint8) level;
	send_data_with_crc (&data);
}

void cfont_set_backlight (const int level_percent) {
	LCD_SEND_DATA data;
	int level;
	level = level_percent;
	data.packet.type = 14;
	data.packet.length = 1;
	data.packet.info[0] = (uint8) level;
	send_data_with_crc (&data);
}

void cfont_set_led (const int led, const int g_level, const int r_level)
{
	LCD_SEND_DATA data;
	if (g_level >= 0)
	{
		int led_number = 12 - ((led*2)-2);
		data.packet.type = 34;
		data.packet.length = 2;
		data.packet.info[0] = (uint8) led_number;
		data.packet.info[1] = (uint8) g_level;
		send_data_with_crc (&data);
	}
	if (r_level >= 0)
	{
		int led_number = 12 - ((led*2)-1);
		data.packet.type = 34;
		data.packet.length = 2;
		data.packet.info[0] = (uint8) led_number;
		data.packet.info[1] = (uint8) r_level;
		send_data_with_crc (&data);
	}
}

void cfont_write_xy (const int x, const int y, const char *s, const int l) {
	LCD_SEND_DATA data;
	int len = l;
	int i;
	if (x + len - 1 > 20) {
		len = 20 - x + 1;
	}
	data.packet.type      = 31;
	data.packet.length    = len + 2;
	data.packet.info[0]   = (uint8) x;
	data.packet.info[1]   = (uint8) y;
	for (i=0; i < len; i++) {
		data.packet.info[2+i] = (uint8) s[i];
	}
	send_data_with_crc (&data);
}

void cfont_write_char_xy (const int x, const int y, const uint8 c) {
	LCD_SEND_DATA data;
	data.packet.type      = 31;
	data.packet.length    = 3;
	data.packet.info[0]   = (uint8) x;
	data.packet.info[1]   = (uint8) y;
	data.packet.info[2]   = c;
	send_data_with_crc (&data);
}


void cfont_define_char (const int index, const uint8 matrix[8]) {
	LCD_SEND_DATA data;
	int i;
	data.packet.type    = 9;
	data.packet.length  = 9;
	data.packet.info[0] = (uint8) index;
	for (i=0; i < 8; i++) {
		data.packet.info[i+1] = matrix[i];
	}
	send_data_with_crc (&data);
}

void cfont_get_ddcgram (const int addr)
{
	LCD_SEND_DATA data;
	data.packet.type	= 10;
	data.packet.length	= 1;
	data.packet.info[0] = (uint8) addr;
	send_data_with_crc (&data);
}

/*************************************************************************/
/**  COMMUNICATION FUCTIONS                                             **/
/*************************************************************************/

int cfont_open (const char *device) {
        struct termios portset;

        __fd = open (device, O_RDWR | O_NOCTTY | O_NDELAY);

        if (__fd == -1) {
				// return -1... let the program deal with it
                return -1;
        }

        tcgetattr (__fd, &portset);

        // configuration
        portset.c_iflag &= ~( IGNBRK | BRKINT | PARMRK | ISTRIP
                              | INLCR | IGNCR | ICRNL | IXON );
        portset.c_oflag &= ~OPOST;
        portset.c_lflag &= ~( ECHO | ECHONL | ICANON | ISIG | IEXTEN );
        portset.c_cflag &= ~( CSIZE | PARENB | CSTOPB | CRTSCTS );
        portset.c_cflag |= CS8 | CREAD | CLOCAL ;

        cfsetospeed (&portset, B115200);
        cfsetispeed (&portset, B0);             /* same than output speed */

        if (tcsetattr (__fd, TCSANOW, &portset) == -1) {
				return -1;
        }

        /* init the lcd send buffer */
        __lcd_send_buffer.head = __lcd_send_buffer.tail = 0;
        __lcd_send_buffer.len  = 0;

        __lcd_send_buffer.reset_after_end = 1;

        /* launch the main thread */
        __thread_loop = 1;

        pthread_mutex_init(&__send_buffer_mutex, NULL);
        pthread_create(&__lcd_thread, NULL, lcd_635_thread, NULL);

        return __fd;
}

void cfont_close () {
        if (__fd == 0) {
                return;
        }
        __thread_loop = 0;
        pthread_join (__lcd_thread, NULL);
        pthread_mutex_destroy (&__send_buffer_mutex);
}

void cfont_reset_after_end (int on) {
        __lcd_send_buffer.reset_after_end = on;
}

static void send_data_with_crc (LCD_SEND_DATA *data) {
        WORD crc;
        LCD_SEND_DATA *packet;
        if (__fd == 0) {
				// make sure __fd hasn't exploded or something
                return;
        }
        crc.word  = get_crc (data->buffer, data->packet.length + 2, 0xffff);
        data->packet.info[data->packet.length]   = crc.byte[0];
        data->packet.info[data->packet.length+1] = crc.byte[1];
        packet = (LCD_SEND_DATA *) malloc (sizeof(LCD_SEND_DATA));
        memcpy (packet, data, data->packet.length + 4);
        /* tail */
        /* mutex exclusion */
        pthread_mutex_lock (&__send_buffer_mutex);
        __lcd_send_buffer.buffer[__lcd_send_buffer.tail] = packet;
        __lcd_send_buffer.tail ++;
        if (__lcd_send_buffer.tail == BUFFER_MAX_SIZE) {
                __lcd_send_buffer.tail = 0;
        }
        __lcd_send_buffer.len ++;
        pthread_mutex_unlock (&__send_buffer_mutex);
}

static void dispatch_lcd_event (LCD_PACKET_DATA p) {
	// Just send the entire packet to the handler
	// since we don't care if it's a keypress or a data event.
	if (__lcd_send_buffer.event_handler) {
		__lcd_send_buffer.event_handler (&p, __lcd_send_buffer.info);
	}
}

void cfont_register_event_handler (void (*event_handler) (LCD_PACKET_DATA *p, void *info), void *info) {
        __lcd_send_buffer.event_handler = event_handler;
        __lcd_send_buffer.info = info;
}

//CRC table
static uint16 cfont_crc_table[256] =
    {0x00000,0x01189,0x02312,0x0329B,0x04624,0x057AD,0x06536,0x074BF,
     0x08C48,0x09DC1,0x0AF5A,0x0BED3,0x0CA6C,0x0DBE5,0x0E97E,0x0F8F7,
     0x01081,0x00108,0x03393,0x0221A,0x056A5,0x0472C,0x075B7,0x0643E,
     0x09CC9,0x08D40,0x0BFDB,0x0AE52,0x0DAED,0x0CB64,0x0F9FF,0x0E876,
     0x02102,0x0308B,0x00210,0x01399,0x06726,0x076AF,0x04434,0x055BD,
     0x0AD4A,0x0BCC3,0x08E58,0x09FD1,0x0EB6E,0x0FAE7,0x0C87C,0x0D9F5,
     0x03183,0x0200A,0x01291,0x00318,0x077A7,0x0662E,0x054B5,0x0453C,
     0x0BDCB,0x0AC42,0x09ED9,0x08F50,0x0FBEF,0x0EA66,0x0D8FD,0x0C974,
     0x04204,0x0538D,0x06116,0x0709F,0x00420,0x015A9,0x02732,0x036BB,
     0x0CE4C,0x0DFC5,0x0ED5E,0x0FCD7,0x08868,0x099E1,0x0AB7A,0x0BAF3,
     0x05285,0x0430C,0x07197,0x0601E,0x014A1,0x00528,0x037B3,0x0263A,
     0x0DECD,0x0CF44,0x0FDDF,0x0EC56,0x098E9,0x08960,0x0BBFB,0x0AA72,
     0x06306,0x0728F,0x04014,0x0519D,0x02522,0x034AB,0x00630,0x017B9,
     0x0EF4E,0x0FEC7,0x0CC5C,0x0DDD5,0x0A96A,0x0B8E3,0x08A78,0x09BF1,
     0x07387,0x0620E,0x05095,0x0411C,0x035A3,0x0242A,0x016B1,0x00738,
     0x0FFCF,0x0EE46,0x0DCDD,0x0CD54,0x0B9EB,0x0A862,0x09AF9,0x08B70,
     0x08408,0x09581,0x0A71A,0x0B693,0x0C22C,0x0D3A5,0x0E13E,0x0F0B7,
     0x00840,0x019C9,0x02B52,0x03ADB,0x04E64,0x05FED,0x06D76,0x07CFF,
     0x09489,0x08500,0x0B79B,0x0A612,0x0D2AD,0x0C324,0x0F1BF,0x0E036,
     0x018C1,0x00948,0x03BD3,0x02A5A,0x05EE5,0x04F6C,0x07DF7,0x06C7E,
     0x0A50A,0x0B483,0x08618,0x09791,0x0E32E,0x0F2A7,0x0C03C,0x0D1B5,
     0x02942,0x038CB,0x00A50,0x01BD9,0x06F66,0x07EEF,0x04C74,0x05DFD,
     0x0B58B,0x0A402,0x09699,0x08710,0x0F3AF,0x0E226,0x0D0BD,0x0C134,
     0x039C3,0x0284A,0x01AD1,0x00B58,0x07FE7,0x06E6E,0x05CF5,0x04D7C,
     0x0C60C,0x0D785,0x0E51E,0x0F497,0x08028,0x091A1,0x0A33A,0x0B2B3,
     0x04A44,0x05BCD,0x06956,0x078DF,0x00C60,0x01DE9,0x02F72,0x03EFB,
     0x0D68D,0x0C704,0x0F59F,0x0E416,0x090A9,0x08120,0x0B3BB,0x0A232,
     0x05AC5,0x04B4C,0x079D7,0x0685E,0x01CE1,0x00D68,0x03FF3,0x02E7A,
     0x0E70E,0x0F687,0x0C41C,0x0D595,0x0A12A,0x0B0A3,0x08238,0x093B1,
     0x06B46,0x07ACF,0x04854,0x059DD,0x02D62,0x03CEB,0x00E70,0x01FF9,
     0x0F78F,0x0E606,0x0D49D,0x0C514,0x0B1AB,0x0A022,0x092B9,0x08330,
     0x07BC7,0x06A4E,0x058D5,0x0495C,0x03DE3,0x02C6A,0x01EF1,0x00F78};

static uint16 get_crc(const uint8 *buffer, uint16 len, const uint16 s) {
        uint16 crc = 0x0ffff;
        crc=s;
        //Algorithim based on the IrDA LAP example.
        while(len--) {
                crc = (crc >> 8) ^ cfont_crc_table[(crc ^ *buffer++) & 0xff];
        }
        return(~crc);
}

static void* lcd_635_thread (void *thread_data) {
	LCD_SEND_DATA *data;
	int waiting_for_ack = 0;
	LCD_RECEIVE_DATA receive;
	fd_set readfs;
	int res;
	struct timeval timeout;
	int num_send = 0;
	int packets;
	int state=1, sig_state = 0;
	int k = 0, crc_i = 0;
	uint8 buf[256];
	int i;
	timeout.tv_sec  = 0;
	FD_ZERO (&readfs);
	data = NULL;
	while (__thread_loop || (__lcd_send_buffer.len > 0 || data != NULL)) {
		if (!waiting_for_ack && __lcd_send_buffer.len > 0) {
			pthread_mutex_lock (&__send_buffer_mutex);
			data = __lcd_send_buffer.buffer[__lcd_send_buffer.head++];
			__lcd_send_buffer.len --;
			if (__lcd_send_buffer.head == BUFFER_MAX_SIZE) {
				__lcd_send_buffer.head = 0;
			}
			pthread_mutex_unlock (&__send_buffer_mutex);
			
			write (__fd, data->buffer, data->packet.length+4);
			num_send = 1;
			waiting_for_ack = 1;
		}
		FD_SET (__fd, &readfs);
		// 250mS wait for ack, afterwards stop & retry
		timeout.tv_usec = 250000;
		res = select(FD_SETSIZE, &readfs, NULL, NULL, &timeout);
		if (res == 0) { // timeout
                        // repeat last send if any
			if (data) {
				if (num_send >= 3) {
					fprintf (stderr, "CFONT635: Packet lost %d\n", data->packet.type);
					free (data);
					data = NULL;
					waiting_for_ack = 0;
				} else {
					write (__fd, data->buffer, data->packet.length+4);
					num_send ++;
					waiting_for_ack = 1;
				}
			}
		} else { // data available, maybe ack or asynchronous message
			packets = read (__fd, buf, 256);
			for (i=0; i < packets; i++) {
				/* a simple state machine read data from buffer */
				switch (state) {
					case 1:
						receive.packet.type = buf[i];
						sig_state = 2;
						break;
					case 2:
						receive.packet.length = buf[i];
						k = 0;
						if (receive.packet.length==0) {
							crc_i = 0;
							sig_state = 4;
						} else {
							sig_state = 3;
						}
							break;
					case 3:
						receive.packet.info[k] = buf[i];
						k++;
						if (k == receive.packet.length) {
							crc_i = 0;
							sig_state = 4;
						} else {
							sig_state = 3;
						}
							break;
					case 4:
						receive.packet.info[k + crc_i] = buf [i];
						crc_i ++;
						if (crc_i == 2) {
							sig_state = 1;
							if (waiting_for_ack &&
								(0x40 | data->packet.type)==receive.packet.type) {
								free (data);
								data = NULL;
								waiting_for_ack = 0;
							}
							// Yes. It's true.
							// We no longer switch depending on what the packet type is
							// since the CFA displays are capable of many, many packet types
							// instead, we just dispatch the packet upon receive to the handler
							// which presumably resides in a different file, and has the smarts
							// to deal with the packet there.
							// This way, we can receive acks and data from packets OTHER THEN
							// key events (such as firmware flashrom contents, and hw/sw versions)
							dispatch_lcd_event(receive.packet);
						} else {
							sig_state = 4;
						}
							break;
				}
				state = sig_state;
			}
		}
	}
	close (__fd);
	__fd = 0;
	pthread_exit(NULL);
	return NULL;
}

/* eof */
