/*
CFLIB - Crystalfontz CFA-635/CFA-631 Control Library
Version 2.0 (2007)
Programmed & Modified by Keven Tipping, Psuedo-Copyright 2007.
Portions of this code from the Crystalfontz Forum.
*/

/*************************************************************************/
/**  INCLUDES                                                           **/
/*************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <termios.h>
#include <unistd.h>
#include <fcntl.h>
#include <ctype.h>
#include <sys/time.h>
#include <sys/types.h>


/*************************************************************************/
/**  TYPEDEFS                                                           **/
/*************************************************************************/

typedef int                int32;
typedef unsigned short int uint16;
typedef unsigned char      uchar8;
typedef unsigned char      uint8;
typedef unsigned int       uint32;

typedef union {
        uint16  word;
        uint8 byte[2];
} WORD;

/* All packets have the following structure:
 *
 * <type><data_length><data><CRC>
 *
 * type is a bitfield with the following values
 *
 * 0x00 - command from host to CFA-635
 * 0x40 - ack/report from CFA-635 to host
 * 0x80 - unsolicited message from CFA-635 to host
 * 0xc0 - command error
 *
 * lower 6 bits of type is the command.
 *
 * data_length value 0-22.
 *
 * CRC is a 16 bit low-endian checksum.
 */
typedef struct {
        uint8 type;
        uint8 length;
        uint8 info[24];
} LCD_PACKET_DATA;

typedef union {
        LCD_PACKET_DATA packet;
        uint8 buffer[256];
} LCD_SEND_DATA;

typedef union {
        LCD_PACKET_DATA packet;
        uint8 buffer[256];
} LCD_RECEIVE_DATA;

#define BUFFER_MAX_SIZE 256

typedef struct {
        LCD_SEND_DATA *buffer[BUFFER_MAX_SIZE];
        int len;
        int tail;
        int head;
        void (*event_handler) (LCD_PACKET_DATA *p, void *info);
        void *info;
        int reset_after_end;
} LCD_SEND_BUFFER;

/*************************************************************************/
/**  CONSTANTS                                                          **/
/*************************************************************************/

/* Report Codes */
#define CFONT635_EVENT_KEY			0x80
#define CFONT635_EVENT_FAN			0x81
#define CFONT635_EVENT_TEMP			0x82

/* Type Codes */
#define CFONT635_EVENT_PING			0x40
#define CFONT635_EVENT_VERSION		0x41
#define CFONT635_EVENT_WRITEFLASH	0x42
#define CFONT635_EVENT_READFLASH	0x43
#define CFONT635_EVENT_STOREBOOT	0x44
#define CFONT635_EVENT_REBOOT		0x45
#define CFONT635_EVENT_CLEAR		0x46
#define CFONT635_EVENT_CGRAM		0x49
#define CFONT635_EVENT_DDRAM		0x4A
#define CFONT635_EVENT_CURSOR		0x4B
#define CFONT635_EVENT_STYLE		0x4C
#define CFONT635_EVENT_CONTRAST		0x4D
#define CFONT635_EVENT_BACKLIGHT	0x4E
#define CFONT635_EVENT_FANREPORT	0x50
#define CFONT635_EVENT_FANPOWER		0x51
#define CFONT635_EVENT_READDOW		0x52
#define CFONT635_EVENT_TEMPREPORT	0x53
#define CFONT635_EVENT_ARBDOW		0x54
#define CFONT635_EVENT_DIRCOMM		0x56
#define CFONT635_EVENT_CONFKEY		0x57
#define CFONT635_EVENT_READKEY		0x58
#define CFONT635_EVENT_FANSAFE		0x59
#define CFONT635_EVENT_TACHGLITCH	0x5A
#define CFONT635_EVENT_QUERYFAN		0x5B
#define CFONT635_EVENT_SETATX		0x5C
#define CFONT635_EVENT_WATCHDOG		0x5D
#define CFONT635_EVENT_GETREPORT	0x5E
#define CFONT635_EVENT_LCDDATA		0x5F
#define CFONT635_EVENT_SETBAUD		0x61
#define CFONT635_EVENT_SETGPIO		0x62
#define CFONT635_EVENT_READGPIO		0x63

/* Keycodes */

#define CFONT635_KEYPAD_PRESS_UP		1
#define CFONT635_KEYPAD_PRESS_DOWN		2
#define CFONT635_KEYPAD_PRESS_LEFT		3
#define CFONT635_KEYPAD_PRESS_RIGHT		4
#define CFONT635_KEYPAD_PRESS_ENTER		5
#define	CFONT635_KEYPAD_PRESS_EXIT		6
#define CFONT635_KEYPAD_RELEASE_UP		7
#define CFONT635_KEYPAD_RELEASE_DOWN	8
#define CFONT635_KEYPAD_RELEASE_LEFTS	9
#define CFONT635_KEYPAD_RELEASE_RIGHT	10
#define CFONT635_KEYPAD_RELEASE_ENTER	11
#define	CFONT635_KEYPAD_RELEASE_EXIT	12


/* Cursor Styles */

#define CFONT635_CURSOR_STYLE_NO_CURSOR         0
#define CFONT635_CURSOR_STYLE_BLINK             1
#define CFONT635_CURSOR_STYLE_UNDERSCORE        2
#define CFONT635_CURSOR_STYLE_BLINK_UNDER       3
#define CFONT635_CURSOR_STYLE_INVERTING_BLINK   4

/*************************************************************************/
/**  FUNCTION PROTOTYPES                                                **/
/*************************************************************************/

extern "C" {
int cfont_open (const char *device);
void cfont_reset ();
void cfont_close ();
void cfont_reset_after_end (const int on);
void cfont_ping(int ping_data);
void cfont_get_version();
void cfont_get_flash();
void cfont_set_flash(const char *string);
void cfont_reboot ();
void cfont_clear ();
void cfont_set_cursor_position (const int x, const int y);
void cfont_set_cursor_style (const int style);
void cfont_set_contrast (const int level_percent);
void cfont_set_backlight (const int level_percent);
void cfont_set_led (const int led, const int g_level, const int r_level);
void cfont_write_xy (const int x, const int y, const char *s, const int len);
void cfont_write_char_xy (const int x, const int y, const uint8 c);
void cfont_define_char (const int index, const uint8 matrix[8]);
void cfont_enable_key_legend (const int kul, const int kur, const int kll, const int klr);
void cfont_disable_key_legend ();
void cfont_store_boot_state ();
void cfont_register_event_handler (void (*event_handler) (LCD_PACKET_DATA *p, void *info), void *info);
void cfont_send_data (LCD_SEND_DATA data);
void cfont_get_ddcgram (const int addr);
}

/* eof */
